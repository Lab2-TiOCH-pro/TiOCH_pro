import os
from openai import OpenAI
from typing import List, Dict, Any
from dotenv import load_dotenv, find_dotenv

# Załaduj zmienne środowiskowe z pliku .env (znajdującego się gdziekolwiek w drzewie)
load_dotenv(find_dotenv())

class LLMDetector:
    """
    Klasa do wykrywania danych wrażliwych za pomocą modelu GPT-4.1 mini.
    """
    
    def __init__(self):
        # Pobranie klucza API z zmiennych środowiskowych
        self.api_key = os.getenv("OPENAI_API_KEY")
        
        # Sprawdzenie, czy klucz API jest dostępny
        if not self.api_key:
            print("Ostrzeżenie: Brak klucza API OpenAI. Ustaw zmienną OPENAI_API_KEY w pliku .env")
            self.client = None
        else:
            # Inicjalizacja klienta OpenAI
            self.client = OpenAI(api_key=self.api_key)
        
        # Ulepszony prompt dla modelu z większym naciskiem na format wyjściowy
        self.prompt_template = """
        Jesteś zaawansowanym systemem do identyfikacji i klasyfikacji danych wrażliwych w dokumentach tekstowych, zgodnym z wymogami RODO. Twoim zadaniem jest przeanalizowanie przekazanego dokumentu (w języku polskim) i wyodrębnienie wszystkich wystąpień danych osobowych lub wrażliwych. Każde znalezione wystąpienie powinno być zwrócone jako obiekt JSON z następującymi polami:
        - "type": kategoria danych (np. "ID", "kontakt", "finansowe", "medyczne", "edukacyjne", "inne")
        - "value": dokładna wykryta wartość
        - "label": bardziej szczegółowa etykieta (np. "PESEL", "EMAIL", "PHONE", "FIRST_NAME", "LAST_NAME", "CREDIT_CARD", "PASSPORT", "ADDRESS")

        Kategorie danych do wykrycia:
        1. **Identyfikatory osobiste (typ: "ID")**  
        • PESEL (11 cyfr)  
        • NIP (10 cyfr, z lub bez myślników)  
        • REGON (9 lub 14 cyfr)  
        • Numery paszportów (np. 2 litery + 7 cyfr lub inne krajowe formaty)  
        • Numery dowodów osobistych (np. 3 litery + 6 cyfr)  
        • Daty urodzenia (formaty DD.MM.YYYY, D-M-YYYY i podobne)

        2. **Dane kontaktowe (typ: "kontakt")**  
        • Adresy e-mail (np. nazwa@domena.pl)  
        • Numery telefonów (krajowe i międzynarodowe, np. +48 123 456 789, 123-456-789)  
        • Adresy zamieszkania (ulica, numer domu/mieszkania, kod pocztowy, miasto)  
        • Kody pocztowe (np. 00-001, 00100)  
        • Nazwy miast, ulic – jeżeli stanowią część pełnego adresu lub mogą jednoznacznie identyfikować lokalizację osoby

        3. **Dane finansowe (typ: "finansowe")**  
        • Numery kont bankowych (IBAN, krajowe NRB)  
        • Numery kart kredytowych i debetowych (16 cyfr, grupowane w 4-4-4-4)  
        • Numer rachunku rozliczeniowego (jeżeli odrębny od NRB/IBAN)

        4. **Dane medyczne (typ: "medyczne")**  
        • Informacje o schorzeniach, diagnozach, zaświadczeniach lekarskich  
        • Orzeczenia o niepełnosprawności  
        • Wyniki badań laboratoryjnych lub inne dane medyczne pozwalające zidentyfikować stan zdrowia

        5. **Dane zawodowe i edukacyjne (typ: "edukacyjne")**  
        • Imiona i nazwiska pracowników lub studentów spoza organizacji  
        • Stanowiska, nazwy instytucji edukacyjnych, wyniki egzaminów, średnie ocen  
        • Informacje o uczelniach, kierunkach studiów (gdy mogą wskazywać na konkretne osoby)

        6. **Inne dane osobowe (typ: "inne")**  
        • Informacje o statusie cywilnym, religii, orientacji seksualnej, gdy występują w tekście  
        • Unikalne identyfikatory wewnętrzne (np. numery pracowników, numery klienta)  

        ZAŁOŻENIA:
        – Przeanalizuj dokument linia po linii.  
        – Dla każdego dopasowania zwróć jedno wystąpienie jako obiekt JSON.  
        – Jeżeli wartość może pasować do kilku kategorii (np. PESEL wygląda jak 11 cyfr), wybierz najbardziej precyzyjną etykietę („PESEL” zamiast ogólnego „ID”).  
        – Zwróć tylko tablicę JSON (lista obiektów). Nie umieszczaj żadnych dodatkowych komentarzy ani wyjaśnień poza JSON-em.  
        – Jeżeli nie znajdziesz żadnych danych wrażliwych, zwróć pustą tablicę: [].

        PRZYKŁAD WYJŚCIA:
        [
        {
            "type": "ID",
            "value": "85010212345",
            "label": "PESEL"
        },
        {
            "type": "kontakt",
            "value": "jan.kowalski@example.com",
            "label": "EMAIL"
        },
        {
            "type": "finansowe",
            "value": "PL61109010140000071219812874",
            "label": "IBAN"
        }
        ]

        TREŚĆ DOKUMENTU:
        {text}
        """
    
    def detect(self, text: str) -> List[Dict[str, Any]]:
        """
        Wykrywa dane wrażliwe w tekście za pomocą modelu GPT-4.1 mini.
        
        Args:
            text: Tekst do analizy
            
        Returns:
            Lista znalezionych danych wrażliwych z informacją o typie, wartości i kontekście
        """
        if not self.client:
            print("Brak klienta OpenAI. Nie można wykonać detekcji za pomocą GPT.")
            return []
        
        try:
            # Przygotowanie promptu
            prompt = self.prompt_template.format(text=text)
            
            # Wywołanie API
            response = self.client.chat.completions.create(
                model="gpt-4.1-mini-2025-04-14",
                messages=[
                    {"role": "system", "content": "Jesteś ekspertem ds. bezpieczeństwa danych i Twoim zadaniem jest wykrywanie danych wrażliwych w dokumentach tekstowych w języku polskim. Przeanalizuj podany tekst i zidentyfikuj wszystkie wystąpienia danych wrażliwych w formacie JSON."},
                    {"role": "user", "content": prompt} 
                ],
                temperature=0.1  
            )
        
            # Parsowanie odpowiedzi GPT i zwrócenie wyników
            content = response.choices[0].message.content
            
            # Usuń zbędne białe znaki i markdownowe znaczniki
            raw = content.strip()
            if raw.startswith("```json") and raw.endswith("```"):
                raw = raw[7:-3].strip()
            elif raw.startswith("```") and raw.endswith("```"):
                raw = raw[3:-3].strip()
            
            # Wyodrębnij samą tablicę lub obiekt JSON
            import re
            import json
            
            # Próba bezpośredniego parsowania
            try:
                return json.loads(raw)
            except json.JSONDecodeError:
                # Jeśli nie udało się, spróbuj wyodrębnić tablicę
                match = re.search(r"(\[.*\])", raw, re.DOTALL)
                if match:
                    json_text = match.group(1)
                    try:
                        return json.loads(json_text)
                    except json.JSONDecodeError:
                        print(f"Nie można przetworzyć wyodrębnionej tablicy JSON")
                        return []
                else:
                    print(f"Nie znaleziono tablicy JSON w odpowiedzi")
                    return []
                
        except Exception as e:
            print(f"Wystąpił błąd podczas detekcji danych wrażliwych za pomocą GPT: {str(e)}")
            return []
