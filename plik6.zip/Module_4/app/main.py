import os
from pathlib import Path
from dotenv import load_dotenv, find_dotenv
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from app.tasks import detect_task, process_document
from app.celery_app import celery
import time
import asyncio

load_dotenv(find_dotenv())

class DetectRequest(BaseModel):
    text: Optional[str] = None
    document_id: Optional[str] = None

class DetectionResult(BaseModel):
    type: str
    value: str
    label: str

app = FastAPI(
    title="Sensitive Data Detection Service",
    version="1.0"
)

@app.get("/health")
async def health_check():
    return {"status": "ok"}

@app.post("/detect", response_model=List[DetectionResult])
async def detect(request: DetectRequest):
    try:
        # Sprawdź, czy podano document_id do pobrania z bazy
        if request.document_id:
            # Pobierz dokument z bazy, analizuj i zapisz wyniki
            return await process_document(request.document_id)
        
        # Jeśli nie podano document_id, sprawdź czy podano tekst do analizy
        elif request.text:
            # Sprawdź, czy klucz API OpenAI jest dostępny
            if not os.getenv("OPENAI_API_KEY"):
                use_llm = False
            else:
                use_llm = True
                
            # Enqueue the task
            task = detect_task.delay(request.text, None, use_llm)
            
            # Wait for the task to complete (with timeout)
            timeout = 30  # seconds
            start_time = time.time()
            
            while time.time() - start_time < timeout:
                async_result = celery.AsyncResult(task.id)
                if async_result.ready():
                    if async_result.successful():
                        return async_result.result
                    else:
                        # Task failed
                        raise HTTPException(status_code=500, detail=f"Task failed: {str(async_result.result)}")
                # Wait a bit before checking again
                time.sleep(0.1)
            
            # If we reach here, the task timed out
            raise HTTPException(status_code=408, detail="Request timeout while processing text")
        else:
            # Jeśli nie podano ani document_id, ani tekstu, zwróć błąd
            raise HTTPException(status_code=400, detail="Either document_id or text must be provided")
    except Exception as e:
        # Catch any other exceptions
        raise HTTPException(status_code=500, detail=f"Error processing request: {str(e)}")
