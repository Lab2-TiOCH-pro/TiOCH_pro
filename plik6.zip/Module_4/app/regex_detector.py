import re
from typing import List, Dict, Any

class RegexDetector:
    """
    Klasa do wykrywania danych wrażliwych za pomocą wyrażeń regularnych i słów-kluczy.
    """
    def __init__(self):
        # Wzorce regex dla danych wrażliwych - ulepszone wzorce
        self.patterns = {
            # Identyfikatory osobiste - ulepszone wzorce
            "PESEL":      {"regex": re.compile(r"\b\d{11}\b"), "type": "ID"},
            "NIP":        {"regex": re.compile(r"\b\d{3}[-\s]?\d{3}[-\s]?\d{2}[-\s]?\d{2}\b"), "type": "ID"},
            "REGON":      {"regex": re.compile(r"\b\d{9}(?:\d{5})?\b"), "type": "ID"},
            "PASSPORT":   {"regex": re.compile(r"\b[A-Z]{2}\d{7}\b"), "type": "ID"},
            "ID_CARD":    {"regex": re.compile(r"\b[A-Z]{3}\s?\d{6}\b"), "type": "ID"}, # Dowód osobisty
            "DATE":       {"regex": re.compile(r"\b\d{2}[./-]\d{2}[./-]\d{4}\b"), "type": "ID"},
            
            # Dane kontaktowe - ulepszone wzorce
            "EMAIL":      {"regex": re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"), "type": "kontakt"},
            "PHONE":      {"regex": re.compile(r"(?<!\d)(?:\+?48\s?)?(?:\d{3}[-\s]?\d{3}[-\s]?\d{3}|\d{2}[-\s]?\d{3}[-\s]?\d{2}[-\s]?\d{2})(?!\d)"), "type": "kontakt"},
            "ADDRESS":    {"regex": re.compile(r"\b(?:ulica|ul\.|al\.|aleja|osiedle|os\.|plac|pl\.)\s+[A-ZĄĆĘŁŃÓŚŹŻ][\wąćęłńóśźż]+\s+\d+[A-Za-z]?(?:/\d+)?", re.IGNORECASE), "type": "kontakt"},
            "POSTAL_CODE":{"regex": re.compile(r"\b\d{2}[-\s]?\d{3}\b"), "type": "kontakt"},
            "CITY":       {"regex": re.compile(r"\b(?:w\s+)?[A-ZĄĆĘŁŃÓŚŹŻ][\wąćęłńóśźż]+(?:owie|ach|u|ej|cach|sku|cu|nie|niu|owie|ach|ej|ym|im|ej|ym|im)\b", re.IGNORECASE), "type": "kontakt"},
            
            # Dane finansowe - ulepszone wzorce
            "ACCOUNT":    {"regex": re.compile(r"\b(?:[A-Z]{2}\d{2}[-\s]?(?:\d{4}[-\s]?){5}\d{4}|\d{26})\b"), "type": "finansowe"},
            "CREDIT_CARD":{"regex": re.compile(r"\b(?:\d{4}[-\s]?){3}\d{4}\b"), "type": "finansowe"},
            "MONEY":      {"regex": re.compile(r"\b\d+[.,]?\d*\s?(?:PLN|EUR|USD|GBP|zł|złotych|euro|dolarów)\b", re.IGNORECASE), "type": "finansowe"},
            "SALARY":     {"regex": re.compile(r"\b(?:wynagrodzenie|pensja|zarobki|wypłata|dochód)(?:\s+w\s+wysokości)?\s+\d+[.,]?\d*\s?(?:PLN|EUR|USD|GBP|zł|złotych|euro|dolarów)?\b", re.IGNORECASE), "type": "finansowe"},
            "INVOICE":    {"regex": re.compile(r"\b(?:FV|Faktura)\s+(?:nr\s+)?[A-Za-z0-9]+[/\-][A-Za-z0-9]+[/\-]\d{4}\b", re.IGNORECASE), "type": "finansowe"},
        }
        
        # Słowa-klucze dla danych kontekstowych - rozszerzone
        self.keyword_patterns = {
            # Dane medyczne
            "MEDICAL_CERT": {"keywords": ["zaświadczenie lekarskie", "orzeczenie o niepełnosprawności", "zwolnienie lekarskie"], "type": "medyczne"},
            "MEDICAL_INFO": {"keywords": ["diagnoza", "rozpoznanie", "choroba", "schorzenie", "historia choroby"], "type": "medyczne"},
            "MEDICAL_PROC": {"keywords": ["zabieg", "operacja", "leczenie", "terapia", "rehabilitacja"], "type": "medyczne"},
            
            # Dane edukacyjne
            "DEAN_LEAVE":   {"keywords": ["urlop dziekański", "urlop od zajęć"], "type": "edukacyjne"},
            "DISCIPLINARY": {"keywords": ["dyscyplinarne", "przewinień", "komisja dyscyplinarna"], "type": "edukacyjne"},
            "EXAM_PROTOCOL":{"keywords": ["protokoły egzaminacyjne", "protokół egzaminacyjny", "wyniki egzaminu"], "type": "edukacyjne"},
            "THESIS":       {"keywords": ["praca dyplomowa", "praca magisterska", "praca licencjacka", "praca inżynierska"], "type": "edukacyjne"},
            "GRADES":       {"keywords": ["ocena", "stopień", "zaliczenie"], "type": "edukacyjne"},
            
            # Identyfikatory - kontekst
            "PASZPORT_CTX": {"keywords": ["numer paszportu", "nr paszportu", "paszport numer"], "type": "ID"},
            "VISA_CTX":     {"keywords": ["numer wizy", "nr wizy", "wiza numer"], "type": "ID"},
            "DOC_POBYTU":   {"keywords": ["karta pobytu", "dokument pobytowy", "zezwolenie na pobyt"], "type": "ID"},
            "DATA_URODZENIA":{"keywords": ["data urodzenia", "urodzony dnia", "urodzona dnia"], "type": "ID"},
            "PESEL_CTX":    {"keywords": ["numer pesel", "nr pesel", "pesel numer"], "type": "ID"},
            "NIP_CTX":      {"keywords": ["numer nip", "nr nip", "nip numer"], "type": "ID"},
            
            # Dane finansowe - kontekst
            "FAKTURA":      {"keywords": ["faktura", "faktura VAT", "rachunek"], "type": "finansowe"},
            "PAYMENT":      {"keywords": ["płatność", "wpłata", "przelew"], "type": "finansowe"},
            "BANK_ACCOUNT": {"keywords": ["konto bankowe", "rachunek bankowy", "nr konta", "numer rachunku"], "type": "finansowe"},
            
            # Inne wrażliwe dane
            "FAMILY":       {"keywords": ["sytuacja rodzinna", "stan cywilny", "członkowie rodziny"], "type": "inne"},
            "MATERIAL":     {"keywords": ["sytuacja materialna", "sytuacja finansowa", "dochód rodziny"], "type": "inne"},
            "PERSONAL":     {"keywords": ["dane osobowe", "informacje osobiste", "dane wrażliwe"], "type": "inne"},
        }

    def detect(self, text: str) -> List[Dict[str, Any]]:
        """
        Wykrywa dane wrażliwe w tekście za pomocą regex i słów-kluczy.
        """
        results: List[Dict[str, Any]] = []
        # Detekcja przez regex
        for name, pat in self.patterns.items():
            for match in pat["regex"].finditer(text):
                results.append({
                    "type": pat["type"],
                    "value": match.group(),
                    "label": name
                })
        # Detekcja przez słowa-klucze (case-insensitive)
        lower_text = text.lower()
        for name, item in self.keyword_patterns.items():
            for kw in item["keywords"]:
                idx = 0
                while True:
                    idx = lower_text.find(kw, idx)
                    if idx == -1:
                        break
                    results.append({
                        "type": item["type"],
                        "value": text[idx:idx+len(kw)],
                        "label": name
                    })
                    idx += len(kw)
        # Usuń duplikaty (type, value, label)
        unique = []
        seen = set()
        for r in results:
            key = (r.get("type"), r.get("value"), r.get("label"))
            if key not in seen:
                seen.add(key)
                unique.append(r)
        return unique
