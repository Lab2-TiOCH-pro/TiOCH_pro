from app.celery_app import celery
from app.sensitive_detector import SensitiveDataDetector
import os
import httpx
import time
from datetime import datetime
from typing import List, Dict, Any, Optional
import asyncio

async def get_document(document_id: str) -> Dict[str, Any]:
    try:
        module3_url = os.getenv("MODULE3_API_URL", "http://datastore_api:8000/api/documents/")
        url = f"{module3_url}{document_id}"
        async with httpx.AsyncClient() as client:
            response = await client.get(url)
            
        if response.status_code != 200:
            raise Exception(f"Error fetching document: {response.text}")
            
        return response.json()
    except Exception as e:
        raise Exception(f"Failed to fetch document {document_id}: {str(e)}")

async def get_normalized_text(document_id: str):
    try:
        document = await get_document(document_id)
        
        normalized_text = document.get("normalizedText")
        if not normalized_text:
            raise Exception(f"Document {document_id} has no normalized text")
        
        document_identifier = document.get("metadata", {}).get("identifier", document_id)
        
        return normalized_text, document_identifier
    except Exception as e:
        raise Exception(f"Failed to get normalized text for document {document_id}: {str(e)}")

async def process_document(document_id: str) -> List[Dict[str, Any]]:
    try:
        start_time = time.time()
        
        # Pobierz znormalizowany tekst dokumentu
        normalized_text, document_identifier = await get_normalized_text(document_id)
        
        # Wykonaj detekcję danych wrażliwych
        detector = SensitiveDataDetector()
        results = detector.detect(normalized_text)
        
        # Upewnij się, że wyniki są w wymaganym formacie
        formatted_results = []
        for item in results:
            # Upewnij się, że każdy element ma wymagane pola
            if "type" in item and "value" in item:
                formatted_item = {
                    "type": item["type"],
                    "value": item["value"],
                    "label": item.get("label", "UNKNOWN")  # Domyślna etykieta, jeśli brak
                }
                formatted_results.append(formatted_item)
        
        # Oblicz czas analizy
        analysis_time = time.time() - start_time
        
        # Przygotuj dane do aktualizacji w Module 3
        module3_url = os.getenv("MODULE3_API_URL", "http://datastore_api:8000/api/documents/")
        update_url = f"{module3_url}{document_id}"
        
        # Przygotuj wynik analizy
        analysis_result = {
            "status": "completed",
            "timestamp": datetime.now().isoformat(),
            "detectedItems": formatted_results,
            "analysisTime": analysis_time
        }
        
        # Przygotuj dane do aktualizacji
        update_payload = {
            "analysisResult": analysis_result
        }
        
        # Wyślij aktualizację do Module 3
        async with httpx.AsyncClient() as client:
            response = await client.patch(update_url, json=update_payload)
        
        if response.status_code != 200:
            print(f"Error updating document {document_id} in Module 3: {response.text}")
        
        return formatted_results
    except Exception as e:
        print(f"Error processing document {document_id}: {str(e)}")
        
        # W przypadku błędu, zaktualizuj status analizy na "failed"
        try:
            error_payload = {
                "analysisResult": {
                    "status": "failed",
                    "timestamp": datetime.now().isoformat(),
                    "error": str(e),
                    "detectedItems": []
                }
            }
            
            module3_url = os.getenv("MODULE3_API_URL", "http://datastore_api:8000/api/documents/")
            async with httpx.AsyncClient() as client:
                await client.patch(f"{module3_url}{document_id}", json=error_payload)
        except Exception as update_error:
            print(f"Failed to update error status for document {document_id}: {str(update_error)}")
        
        return []

@celery.task(bind=True)
def detect_task(self, text: str, document_id: str = None, use_llm: bool = True):
    start_time = time.time()
    detector = SensitiveDataDetector()
    
    try:
        # Wykonaj detekcję
        results = detector.detect(text)
        
        # Upewnij się, że wyniki są w wymaganym formacie
        formatted_results = []
        for item in results:
            if "type" in item and "value" in item:
                formatted_item = {
                    "type": item["type"],
                    "value": item["value"],
                    "label": item.get("label", "UNKNOWN")
                }
                formatted_results.append(formatted_item)
        
        # If document_id is provided, update Module 3 database with results
        if document_id:
            try:
                # Calculate analysis time
                analysis_time = time.time() - start_time
                
                # Prepare data for Module 3 API
                module3_url = os.getenv("MODULE3_API_URL", "http://datastore_api:8000/api/documents/")
                update_url = f"{module3_url}{document_id}"
                
                # Prepare analysis result payload
                analysis_result = {
                    "status": "completed",
                    "timestamp": datetime.now().isoformat(),
                    "detectedItems": formatted_results,
                    "analysisTime": analysis_time
                }
                
                # Prepare update payload
                update_payload = {
                    "analysisResult": analysis_result
                }
                
                # Send update to Module 3
                response = httpx.patch(update_url, json=update_payload)
                
                if response.status_code != 200:
                    print(f"Error updating document {document_id} in Module 3: {response.text}")
            except Exception as e:
                print(f"Exception updating document {document_id} in Module 3: {str(e)}")
        
        return formatted_results
    except Exception as e:
        print(f"Error in detect_task: {str(e)}")
        return []
